#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "define.h"

/*-*-c++-*-*/

int action(int *sugar_neighbor_info,int *others_neighbor_info,int sugar,int met, int vis, int acq)
{
  
  //$B;k3P>pJs$H<+J,$N>uBV$+$i9TF0$r7hDj(B

  //sugar_neighbor_info[0] $B>e;k3&Fb$K8=:_CO$h$j:=E|$,B?$$>l=j$,$"$l$P(B1, $B$=$l0J30$O(B0
  //sugar_neighbor_info[1] $B2<;k3&Fb$K8=:_CO$h$j:=E|$,B?$$>l=j$,$"$l$P(B1, $B$=$l0J30$O(B0
  //sugar_neighbor_info[2] $B:8;k3&Fb$K8=:_CO$h$j:=E|$,B?$$>l=j$,$"$l$P(B1, $B$=$l0J30$O(B0
  //sugar_neighbor_info[3] $B1&;k3&Fb$K8=:_CO$h$j:=E|$,B?$$>l=j$,$"$l$P(B1, $B$=$l0J30$O(B0

  //others_neighbor_info[0] $B>e6aK5$GB>$N%(!<%8%'%s%H$K@\$7$F$$$l$P(B1, $B$=$l0J30$O(B0
  //others_neighbor_info[1] $B2<6aK5$GB>$N%(!<%8%'%s%H$K@\$7$F$$$l$P(B1, $B$=$l0J30$O(B0
  //others_neighbor_info[2] $B:86aK5$GB>$N%(!<%8%'%s%H$K@\$7$F$$$l$P(B1, $B$=$l0J30$O(B0
  //others_neighbor_info[3] $B1&6aK5$GB>$N%(!<%8%'%s%H$K@\$7$F$$$l$P(B1, $B$=$l0J30$O(B0

  //sugar $B8=:_$N:=E|J]M-NL(B
  //met   $B#1%?!<%s$"$?$j$N:=E|>CHqNL(B
  //vis   $B;k3&$NBg$-$5(B
  //acq   1$B%?!<%s$K@]<h$G$-$k:=E|$NNL(B

  //$B9TF0=PNO(B 0:$B>e(B 1:$B2<(B 2:$B:8(B 3:$B1&(B 4:$BDd;_(B 
  
  int i,j,k;

  int sugar_list[4];
  int num_sugar_direction=0;

  int a,rnd;

  for(i=0;i<4;i++)
    {
      if(sugar_neighbor_info[i] == 1)
	{ 
	  sugar_list[num_sugar_direction]=i;
	  num_sugar_direction++;
	}
    }
  
  if(num_sugar_direction>0)
    {
      a = sugar_list[ rand()%num_sugar_direction ];
    }
  else
    {
      rnd=rand()%6;
      if (rnd==5) rnd=0;
      a = rnd;
      
    }

  return a;

}



