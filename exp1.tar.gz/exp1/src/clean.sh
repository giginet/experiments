rm log*
