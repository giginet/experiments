#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>
#include "define.h"

using namespace std;

/*-*-c++-*-*/

class Agent{
  private:
    vector<int> list_others;
    vector<int> list_sugar;
    int not_collide(vector<int> list);
  public:
    Agent(int* si, int* oi, int s, int m, int v, int a);
    int sugar;
    int met;
    int vis;
    int acq;
    int escape(bool stream);
    int random_walk(bool stream);
    int approach(bool stream);
    double scouter();
    double turn();
    int action();
};

bool contains(vector<int> v, int i);

Agent::Agent(int* si, int* oi, int s, int m, int v, int a){
  for(int i=0;i<4;++i){
    if(si[i] == 1){ 
      list_sugar.push_back(i);
    }
  }
  for(int i=0;i<4;++i){
    if(oi[i] == 1){
      list_others.push_back(i);
    }
  }
  sugar = s;
  met = m;
  vis = v;
  acq = a;
}

bool contains(vector<int> v, int i){
  vector<int>::iterator p = find(v.begin(), v.end(), i);
  return !(p == v.end());
}

int Agent::action(){
  int direction = 4;
  int t = (int)turn();
  if(t <= 0 || met >= 10){
    direction = escape(false);
  }else if(list_others.size() == 4){
    direction = 4; 
  }else if(!list_sugar.empty()){
    if(sugar < min(t/vis * 85, 2000)){
      direction = approach(false);
    }else if(sugar < 5000){
      direction = random_walk(true);
    }else{
      direction = escape(true);
    }
  }else if(list_sugar.empty()){
    direction = random_walk(true);
  }
  return direction;
}

int Agent::escape(bool stream){
  vector<int> nonsugar;
  for(int i=0;i<4;++i){
    if(!contains(list_sugar, i)){
      if(!stream || (stream && i%2==0)){
        nonsugar.push_back(i);
      }
    }
  }
  return not_collide(nonsugar);
  /*  int rnd;
  if(stream){
    int up = contains(list_sugar, 0);
    int left = contains(list_sugar, 2);
    if(up && left){
      return random_walk(true);
    }else if(up){
      return 2;
    }else if(left){
      return 0;
    }
    return random_walk(true);
  }else{
    if(list_sugar.size() == 4){
      return rand()%4;
    }else{
      do{
        rnd = rand()%4;
      }while(contains(list_sugar, rnd));
      return rnd;
    }
  }*/
}

int Agent::not_collide(vector<int> list){
  //$BEO$7$?9T$-$?$$J}8~%j%9%H$+$i!"B>?M$K$V$D$+$i$J$$F;$r$$$$46$8$GA*Br$7$F$-$^$9(B
  //$BC/$b$$$J$$J}8~%j%9%H$r:n$k(B
  vector<int> nobody;
  for(int i=0;i<4;++i){
    if(!contains(list_others, i)) nobody.push_back(i);
  }
  //$B9T$-$?$$J}8~%j%9%H$HC/$b$$$J$$%j%9%H$N@Q=89g$r$H$k(B
  vector<int> set(list.size() + 4);
  vector<int>::iterator end = set_intersection(list.begin(), list.end(), nobody.begin(), nobody.end(), set.begin());
  int size = (int)(end - set.begin());
  if(size == 0){
    // $BB8:_$7$J$1$l$P!"C/$b$$$J$$J}8~$r%i%s%@%`$GJV$9(B
    if(nobody.empty()) return 4;
    return nobody[rand()%nobody.size()];
  }else{
    // $BB8:_$9$l$P%i%s%@%`$GJV5Q(B
    return set[rand()%size];
  }
  return rand()%4;
}

int Agent::random_walk(bool stream){
  vector<int> list;
  list.push_back(0);
  list.push_back(2);
  if(!stream){
    list.push_back(1);
    list.push_back(3);
  }
  return not_collide(list);
  /*int rnd;
  if(stream){
    int left = contains(list_others, 2);
    if(!up || !left){
      do{
        rnd = (rand()%2)*2;
      }while(contains(list_others, rnd));
      return rnd;
    }
    return (rand()%2)*2;
  }else{
    if(list_others.size() == 4) return rand()%4;
    do{
      rnd = rand()%5;
      if (rnd==4) rnd = 0;
    }while(contains(list_others, rnd));
    return rnd;
  }*/
}

double Agent::scouter(){
  return vis * 1000 + (12 - met) * 1000 + acq;
}

double Agent::turn(){ 
  return (4000 * met - 5000)/acq;
}

int Agent::approach(bool stream){
  vector<int> sugar;
  for(vector<int>::iterator it=list_sugar.begin();it<list_sugar.end();++it){
    if( !stream || (stream && *it%2==0) ){
      sugar.push_back(*it);
    }
  }
  return not_collide(sugar);
  /*if(!stream) return list_sugar[rand()%list_sugar.size()];
  int up = contains(list_sugar, 0);
  int left = contains(list_sugar, 2);
  if(up && left){
    return random_walk(true);
  }else if(up){
    return 0;
  }else if(left){
    return 2;
  }
  return random_walk(true);*/
}

int action(int *sugar_neighbor_info, int *others_neighbor_info, int sugar, int met, int vis, int acq){
  Agent* agent = new Agent(sugar_neighbor_info, others_neighbor_info, sugar, met, vis, acq); 
  int direction = agent->action();
  delete agent;
  return direction;
}
